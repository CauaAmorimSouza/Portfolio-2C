function clicou(classe) {
    var newColor;
    if (classe === 'Normal') {
        newColor = 'black';
    } else {
        newColor = getRandomColor();
    }
    document.body.style.backgroundColor = newColor;
}

function getRandomColor() {
    var letters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
