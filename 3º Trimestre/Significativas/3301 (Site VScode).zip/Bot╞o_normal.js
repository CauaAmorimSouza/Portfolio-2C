function clickNormal(botao) {
    botao.style.backgroundColor = "black";
    botao.style.color = "white";
}